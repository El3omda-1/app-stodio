"use client"

import Link from "next/link"
import { Menu, ShoppingCart, Search, Sun, Moon, Languages, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useApp } from "@/lib/app-context"

export function Header() {
  const { language, setLanguage, t, theme, toggleTheme, cartCount, setIsAIOpen } = useApp()

  const Navigation = () => (
    <nav className="space-y-4">
      <Link href="/" className="flex items-center space-x-3 p-2 rounded-lg bg-primary/10">
        <span>🏠</span>
        <span className="font-medium">{t("home")}</span>
      </Link>
      <Link href="/categories" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
        <span>📂</span>
        <span>{t("categories")}</span>
      </Link>
      <Link href="/cart" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
        <span>🛒</span>
        <span>{t("cart")}</span>
        {cartCount > 0 && (
          <Badge variant="destructive" className="ml-auto">
            {cartCount}
          </Badge>
        )}
      </Link>
      <Link href="/wishlist" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
        <span>❤️</span>
        <span>{t("wishlist")}</span>
      </Link>
      <Link href="/orders" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
        <span>📦</span>
        <span>{t("myOrders")}</span>
      </Link>
      <Link href="/profile" className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
        <span>👤</span>
        <span>{t("profile")}</span>
      </Link>
    </nav>
  )

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-50">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <div className="py-4">
                <h2 className="text-lg font-semibold mb-4">Adam's Store</h2>
                <Navigation />
              </div>
            </SheetContent>
          </Sheet>

          <Link href="/" className="text-xl font-bold text-primary">
            Adam's Store
          </Link>

          <div className="flex items-center gap-1">
            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Languages className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLanguage("en")}>
                  <span className={language === "en" ? "font-bold" : ""}>English</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage("ar")}>
                  <span className={language === "ar" ? "font-bold" : ""}>العربية</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage("fr")}>
                  <span className={language === "fr" ? "font-bold" : ""}>Français</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme Toggle */}
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>

            {/* AI Assistant */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsAIOpen(true)}
              className="relative"
            >
              <Sparkles className="h-5 w-5 text-purple-500" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
            </Button>

            {/* Cart */}
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-6 w-6" />
                {cartCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs"
                  >
                    {cartCount}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-3 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input placeholder={t("searchProducts")} className="pl-10 bg-gray-100 dark:bg-gray-800 border-0" />
        </div>
      </div>
    </header>
  )
}
