import { NextResponse } from "next/server"
import { GoogleGenerativeAI } from "@google/generative-ai"

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY || "")

export async function POST(request: Request) {
  try {
    const { message } = await request.json()

    if (!message) {
      return NextResponse.json(
        { error: "Message is required" },
        { status: 400 }
      )
    }

    // Initialize Gemini model
    const model = genAI.getGenerativeModel({ model: "gemini-pro" })

    // System prompt for shopping assistant
    const prompt = `You are a helpful shopping assistant for Adam's Store, an e-commerce platform selling electronics, fashion, home products, sports equipment, books, and beauty products.

Customer question: ${message}

Provide a helpful, concise, and friendly response. Focus on:
- Product recommendations based on customer needs
- Answering questions about product features, prices, and availability
- Helping customers find what they're looking for
- Providing shopping advice and comparisons
- Information about shipping, payments, and policies

Keep responses under 150 words and be conversational.`

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("[v0] Gemini API error:", error)
    return NextResponse.json(
      { error: "Failed to process request" },
      { status: 500 }
    )
  }
}
