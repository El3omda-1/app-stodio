"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, User, Settings, Package, Heart, CreditCard, HelpCircle, LogOut, Edit, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function ProfilePage() {
  const [user] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    avatar: "/placeholder.svg?height=100&width=100",
    memberSince: "January 2023",
    totalOrders: 12,
    totalSpent: 2450,
  })

  const menuItems = [
    {
      icon: Package,
      title: "My Orders",
      subtitle: "Track your orders",
      href: "/orders",
      badge: "3 Active",
    },
    {
      icon: Heart,
      title: "Wishlist",
      subtitle: "Your saved items",
      href: "/wishlist",
      badge: "8 Items",
    },
    {
      icon: CreditCard,
      title: "Payment Methods",
      subtitle: "Manage your cards",
      href: "/payment-methods",
    },
    {
      icon: User,
      title: "Personal Information",
      subtitle: "Update your details",
      href: "/profile/edit",
    },
    {
      icon: Settings,
      title: "Settings",
      subtitle: "App preferences",
      href: "/settings",
    },
    {
      icon: HelpCircle,
      title: "Help & Support",
      subtitle: "Get assistance",
      href: "/support",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="font-semibold">Profile</h1>
          <Link href="/profile/edit">
            <Button variant="ghost" size="icon">
              <Edit className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Profile Header */}
      <section className="bg-white p-6">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Avatar className="h-20 w-20">
              <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
              <AvatarFallback className="text-lg">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <Button size="icon" className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full">
              <Camera className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1">
            <h2 className="text-xl font-bold">{user.name}</h2>
            <p className="text-gray-600">{user.email}</p>
            <p className="text-sm text-gray-500">Member since {user.memberSince}</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{user.totalOrders}</div>
              <div className="text-sm text-gray-600">Total Orders</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">${user.totalSpent}</div>
              <div className="text-sm text-gray-600">Total Spent</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Menu Items */}
      <section className="p-4 space-y-2">
        {menuItems.map((item, index) => (
          <Link key={index} href={item.href}>
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>

                  <div className="flex-1">
                    <h3 className="font-medium">{item.title}</h3>
                    <p className="text-sm text-gray-600">{item.subtitle}</p>
                  </div>

                  {item.badge && (
                    <Badge variant="secondary" className="text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </section>

      {/* Quick Actions */}
      <section className="p-4">
        <h3 className="font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <Link href="/orders">
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 text-center">
                <Package className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">Track Order</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/support">
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 text-center">
                <HelpCircle className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-medium">Get Help</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </section>

      {/* Account Actions */}
      <section className="p-4">
        <Card>
          <CardContent className="p-4 space-y-4">
            <Link href="/settings">
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center space-x-3">
                  <Settings className="h-5 w-5 text-gray-600" />
                  <span>Account Settings</span>
                </div>
                <span className="text-gray-400">›</span>
              </div>
            </Link>

            <Separator />

            <button className="flex items-center justify-between py-2 w-full text-left">
              <div className="flex items-center space-x-3">
                <LogOut className="h-5 w-5 text-red-600" />
                <span className="text-red-600">Sign Out</span>
              </div>
              <span className="text-gray-400">›</span>
            </button>
          </CardContent>
        </Card>
      </section>

      {/* App Info */}
      <section className="p-4 pb-8">
        <div className="text-center text-sm text-gray-500">
          <p>Adam's Store v1.0.0</p>
          <p>Made with ❤️ for global shopping</p>
        </div>
      </section>
    </div>
  )
}
