"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, CreditCard, Truck, Shield, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function CheckoutPage() {
  const [paymentMethod, setPaymentMethod] = useState("stripe")
  const [shippingMethod, setShippingMethod] = useState("standard")

  const orderItems = [
    { id: 1, name: "Wireless Headphones", price: 299, quantity: 1 },
    { id: 2, name: "Smart Watch", price: 199, quantity: 2 },
  ]

  const subtotal = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = shippingMethod === "express" ? 15 : 5
  const tax = subtotal * 0.1
  const total = subtotal + shipping + tax

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="flex items-center px-4 py-3">
          <Link href="/cart">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="font-semibold ml-4">Checkout</h1>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Shipping Address */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <MapPin className="mr-2 h-5 w-5" />
              Shipping Address
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" placeholder="John" />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" placeholder="Doe" />
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="john@example.com" />
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" placeholder="+1 (555) 123-4567" />
            </div>

            <div>
              <Label htmlFor="address">Street Address</Label>
              <Input id="address" placeholder="123 Main Street" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="city">City</Label>
                <Input id="city" placeholder="New York" />
              </div>
              <div>
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input id="zipCode" placeholder="10001" />
              </div>
            </div>

            <div>
              <Label htmlFor="country">Country</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="us">United States</SelectItem>
                  <SelectItem value="eg">Egypt</SelectItem>
                  <SelectItem value="sa">Saudi Arabia</SelectItem>
                  <SelectItem value="ae">UAE</SelectItem>
                  <SelectItem value="uk">United Kingdom</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Shipping Method */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Truck className="mr-2 h-5 w-5" />
              Shipping Method
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="standard" id="standard" />
                <Label htmlFor="standard" className="flex-1 cursor-pointer">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Standard Shipping</p>
                      <p className="text-sm text-gray-600">5-7 business days</p>
                    </div>
                    <span className="font-medium">$5.00</span>
                  </div>
                </Label>
              </div>

              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="express" id="express" />
                <Label htmlFor="express" className="flex-1 cursor-pointer">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Express Shipping</p>
                      <p className="text-sm text-gray-600">2-3 business days</p>
                    </div>
                    <span className="font-medium">$15.00</span>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <CreditCard className="mr-2 h-5 w-5" />
              Payment Method
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              All transactions are secure and encrypted
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              {/* Stripe Card Payment */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="stripe" id="stripe" />
                <Label htmlFor="stripe" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <span className="font-medium">Credit/Debit Card</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <div className="w-8 h-5 bg-blue-600 rounded flex items-center justify-center text-white text-[8px] font-bold">
                          VISA
                        </div>
                        <div className="w-8 h-5 bg-red-600 rounded flex items-center justify-center text-white text-[8px] font-bold">
                          MC
                        </div>
                        <div className="w-8 h-5 bg-blue-500 rounded flex items-center justify-center text-white text-[8px] font-bold">
                          AMEX
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Powered by Stripe</p>
                </Label>
              </div>

              {/* PayPal */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="paypal" id="paypal" />
                <Label htmlFor="paypal" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">
                        P
                      </div>
                      <span className="font-medium">PayPal</span>
                    </div>
                    <div className="flex items-center">
                      <div className="px-2 py-1 bg-blue-50 rounded text-xs text-blue-700 font-medium">
                        Safe & Secure
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Fast checkout with PayPal account</p>
                </Label>
              </div>

              {/* Cryptocurrency - USDT */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="usdt" id="usdt" />
                <Label htmlFor="usdt" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                        ₮
                      </div>
                      <span className="font-medium">USDT (Tether)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="px-2 py-1 bg-green-50 rounded text-xs text-green-700 font-medium">
                        Stablecoin
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Pay with USDT on multiple networks</p>
                </Label>
              </div>

              {/* Cryptocurrency - USDC */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="usdc" id="usdc" />
                <Label htmlFor="usdc" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                        $
                      </div>
                      <span className="font-medium">USDC (USD Coin)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="px-2 py-1 bg-blue-50 rounded text-xs text-blue-700 font-medium">
                        Stablecoin
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Pay with USDC stablecoin</p>
                </Label>
              </div>

              {/* Pi Network */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="pi" id="pi" />
                <Label htmlFor="pi" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                        π
                      </div>
                      <span className="font-medium">Pi Network</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="px-2 py-1 bg-purple-50 rounded text-xs text-purple-700 font-medium">
                        Beta
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Pay with Pi cryptocurrency</p>
                </Label>
              </div>

              {/* Cash on Delivery */}
              <div className="flex items-center space-x-2 p-4 border rounded-lg hover:border-primary transition-colors">
                <RadioGroupItem value="cod" id="cod" />
                <Label htmlFor="cod" className="flex-1 cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 bg-gray-600 rounded flex items-center justify-center text-white text-xs font-bold">
                        $
                      </div>
                      <span className="font-medium">Cash on Delivery</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Pay when you receive your order</p>
                </Label>
              </div>
            </RadioGroup>

            {/* Payment Details Forms */}
            {paymentMethod === "stripe" && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
                <div>
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input
                    id="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    className="bg-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input id="expiry" placeholder="MM/YY" className="bg-white" />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" placeholder="123" type="password" className="bg-white" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="cardName">Cardholder Name</Label>
                  <Input id="cardName" placeholder="John Doe" className="bg-white" />
                </div>

                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>Secured by Stripe with 256-bit SSL encryption</span>
                </div>
              </div>
            )}

            {paymentMethod === "paypal" && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-center text-muted-foreground mb-3">
                  You will be redirected to PayPal to complete your purchase
                </p>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Continue with PayPal
                </Button>
              </div>
            )}

            {(paymentMethod === "usdt" || paymentMethod === "usdc") && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
                <div>
                  <Label htmlFor="network">Select Network</Label>
                  <Select>
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Choose blockchain network" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ethereum">Ethereum (ERC-20)</SelectItem>
                      <SelectItem value="bsc">Binance Smart Chain (BEP-20)</SelectItem>
                      <SelectItem value="tron">Tron (TRC-20)</SelectItem>
                      <SelectItem value="polygon">Polygon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="walletAddress">Your Wallet Address</Label>
                  <Input
                    id="walletAddress"
                    placeholder="0x..."
                    className="bg-white font-mono text-xs"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>Transaction will be verified on blockchain</span>
                </div>
              </div>
            )}

            {paymentMethod === "pi" && (
              <div className="mt-4 p-4 bg-purple-50 rounded-lg space-y-3">
                <p className="text-sm text-center text-muted-foreground mb-2">
                  Connect your Pi Network wallet to complete payment
                </p>
                <div>
                  <Label htmlFor="piWallet">Pi Wallet Address</Label>
                  <Input
                    id="piWallet"
                    placeholder="Your Pi wallet address"
                    className="bg-white font-mono text-xs"
                  />
                </div>
                <div className="flex items-center gap-2 text-xs text-amber-700 bg-amber-50 p-2 rounded">
                  <span className="font-medium">⚠️ Note:</span>
                  <span>Pi Network payment is subject to network availability</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Order Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Order Notes (Optional)</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea placeholder="Any special instructions for your order..." className="min-h-[80px]" />
          </CardContent>
        </Card>

        {/* Order Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {orderItems.map((item) => (
                <div key={item.id} className="flex justify-between">
                  <span className="text-sm">
                    {item.name} × {item.quantity}
                  </span>
                  <span className="text-sm font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}

              <Separator />

              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Shipping</span>
                <span>${shipping.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>

              <Separator />

              <div className="flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security & Trust Badges */}
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center text-green-800 font-medium">
              <Shield className="mr-2 h-5 w-5" />
              <span className="text-sm">Secure Payment Guaranteed</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 bg-white rounded">
                <div className="text-xs font-semibold text-gray-700">SSL</div>
                <div className="text-[10px] text-muted-foreground">Encrypted</div>
              </div>
              <div className="p-2 bg-white rounded">
                <div className="text-xs font-semibold text-gray-700">PCI DSS</div>
                <div className="text-[10px] text-muted-foreground">Compliant</div>
              </div>
              <div className="p-2 bg-white rounded">
                <div className="text-xs font-semibold text-gray-700">3D Secure</div>
                <div className="text-[10px] text-muted-foreground">Protected</div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              All payment methods use industry-standard encryption to protect your data
            </p>
          </CardContent>
        </Card>

        {/* Place Order Button */}
        <Button className="w-full" size="lg">
          Place Order - ${total.toFixed(2)}
        </Button>

        {/* Bottom Padding */}
        <div className="h-4"></div>
      </div>
    </div>
  )
}
