"use client"

import Image from "next/image"
import Link from "next/link"
import { 
  Heart, 
  Star, 
  ArrowRight, 
  Home, 
  LayoutGrid, 
  Search, 
  ShoppingCart, 
  User,
  Smartphone,
  Shirt,
  Home as HomeIcon,
  Trophy,
  BookOpen,
  Sparkles
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { useApp } from "@/lib/app-context"

export default function HomePage() {
  const { t, cartCount } = useApp()

  // تم استبدال الإيموجي بأيقونات احترافية من مكتبة lucide-react وتنسيق ألوانها
  const categories = [
    { nameKey: "electronics", icon: <Smartphone className="w-6 h-6" />, color: "bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300", slug: "electronics" },
    { nameKey: "fashion", icon: <Shirt className="w-6 h-6" />, color: "bg-pink-100 text-pink-600 dark:bg-pink-900 dark:text-pink-300", slug: "fashion" },
    { nameKey: "homeProducts", icon: <HomeIcon className="w-6 h-6" />, color: "bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300", slug: "home" },
    { nameKey: "sports", icon: <Trophy className="w-6 h-6" />, color: "bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-300", slug: "sports" },
    { nameKey: "books", icon: <BookOpen className="w-6 h-6" />, color: "bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300", slug: "books" },
    { nameKey: "beauty", icon: <Sparkles className="w-6 h-6" />, color: "bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-300", slug: "beauty" },
  ]

  const featuredProducts = [
    {
      id: 1,
      name: "Wireless Headphones",
      price: 299,
      originalPrice: 399,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.5,
      reviews: 128,
      discount: 25,
    },
    {
      id: 2,
      name: "Smart Watch",
      price: 199,
      originalPrice: 249,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.8,
      reviews: 89,
      discount: 20,
    },
    {
      id: 3,
      name: "Bluetooth Speaker",
      price: 79,
      originalPrice: 99,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.3,
      reviews: 156,
      discount: 20,
    },
    {
      id: 4,
      name: "Phone Case",
      price: 29,
      originalPrice: 39,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.6,
      reviews: 234,
      discount: 26,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Header />

      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-primary to-primary/80 text-white p-6 mx-4 mt-4 rounded-lg shadow-sm">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">{t("welcomeTitle")}</h1>
          <p className="text-primary-foreground/90 mb-4">{t("welcomeSubtitle")}</p>
          <Button variant="secondary" size="sm" className="font-semibold">
            {t("shopNow")}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Categories */}
      <section className="p-4">
        <h2 className="text-lg font-semibold mb-4">{t("shopByCategory")}</h2>
        <div className="grid grid-cols-3 gap-3">
          {categories.map((category, index) => (
            <Link key={index} href={`/category/${category.slug}`}>
              <Card className="hover:shadow-md transition-all duration-200 dark:bg-gray-900 border-transparent hover:border-primary/20">
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 ${category.color} rounded-full flex items-center justify-center mx-auto mb-2`}>
                    {category.icon}
                  </div>
                  <p className="text-xs font-medium">{t(category.nameKey)}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">{t("featuredProducts")}</h2>
          <Link href="/products" className="text-primary text-sm font-medium hover:underline">
            {t("viewAll")}
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {featuredProducts.map((product) => (
            <Link key={product.id} href={`/product/${product.id}`}>
              <Card className="hover:shadow-md transition-shadow dark:bg-gray-900 h-full">
                <CardContent className="p-3 flex flex-col h-full">
                  <div className="relative mb-3 group">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="w-full h-32 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.discount > 0 && (
                      <Badge className="absolute top-2 left-2 bg-red-500 shadow-sm">-{product.discount}%</Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 h-8 w-8 bg-white/80 hover:bg-white dark:bg-gray-800/80 dark:hover:bg-gray-800 backdrop-blur-sm rounded-full"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <h3 className="font-medium text-sm mb-1 line-clamp-2 flex-grow">{product.name}</h3>

                  <div className="flex items-center mb-2 mt-auto">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-baseline gap-1">
                      <span className="font-bold text-primary">${product.price}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-xs text-gray-500 line-through">${product.originalPrice}</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Special Offers */}
      <section className="p-4 mb-4">
        <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-none shadow-md">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-bold mb-2 flex items-center justify-center gap-2">
              <Sparkles className="h-5 w-5" />
              {t("flashSale")}
            </h3>
            <p className="mb-4 text-white/90 text-sm">{t("flashSaleDescription")}</p>
            <Button variant="secondary" size="sm" className="w-full sm:w-auto font-semibold text-red-600 hover:text-red-700">
              {t("shopFlashSale")}
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Bottom Navigation (Mobile Only) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800 px-4 py-2 md:hidden z-50 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <div className="flex justify-around items-center">
          <Link href="/" className="flex flex-col items-center py-1 text-primary">
            <Home className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{t("home")}</span>
          </Link>
          <Link href="/categories" className="flex flex-col items-center py-1 text-gray-500 dark:text-gray-400 hover:text-primary transition-colors">
            <LayoutGrid className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{t("categories")}</span>
          </Link>
          <Link href="/search" className="flex flex-col items-center py-1 text-gray-500 dark:text-gray-400 hover:text-primary transition-colors">
            <Search className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{t("search")}</span>
          </Link>
          <Link href="/cart" className="flex flex-col items-center py-1 text-gray-500 dark:text-gray-400 hover:text-primary transition-colors relative">
            <ShoppingCart className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{t("cart")}</span>
            {cartCount > 0 && (
              <Badge variant="destructive" className="absolute -top-1 0 h-4 min-w-[16px] flex items-center justify-center text-[9px] px-1">
                {cartCount}
              </Badge>
            )}
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-1 text-gray-500 dark:text-gray-400 hover:text-primary transition-colors">
            <User className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium">{t("profile")}</span>
          </Link>
        </div>
      </nav>

      {/* Bottom Padding for Fixed Navigation (Mobile Only) */}
      <div className="h-20 md:hidden"></div>
    </div>
  )
}