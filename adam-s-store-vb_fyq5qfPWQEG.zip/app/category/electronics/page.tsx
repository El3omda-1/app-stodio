"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Star, Filter, SlidersHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export default function ElectronicsPage() {
  const [sortBy, setSortBy] = useState("popular")

  const featuredProducts = [
    {
      id: 1,
      name: "iPhone 15 Pro Max",
      price: 1199,
      originalPrice: 1299,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 567,
      discount: 8,
      badge: "New",
      description: "Latest flagship with A17 Pro chip and titanium design",
    },
    {
      id: 2,
      name: "Samsung Galaxy S24 Ultra",
      price: 1099,
      originalPrice: 1199,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 423,
      discount: 8,
      badge: "Trending",
      description: "Powerful Android flagship with S Pen and AI features",
    },
    {
      id: 3,
      name: "MacBook Pro 16-inch M3",
      price: 2499,
      originalPrice: 2699,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 312,
      discount: 7,
      badge: "New",
      description: "Professional laptop with M3 chip for ultimate performance",
    },
  ]

  const products = [
    {
      id: 4,
      name: "Sony WH-1000XM5",
      price: 349,
      originalPrice: 399,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.7,
      reviews: 892,
      discount: 13,
      description: "Industry-leading noise canceling wireless headphones",
    },
    {
      id: 5,
      name: "iPad Pro 12.9-inch",
      price: 1099,
      originalPrice: 1199,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.8,
      reviews: 445,
      discount: 8,
      description: "Powerful tablet with M2 chip and Liquid Retina display",
    },
    {
      id: 6,
      name: "Dell XPS 13 Plus",
      price: 1299,
      originalPrice: 1499,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.6,
      reviews: 234,
      discount: 13,
      description: "Ultra-portable laptop with stunning InfinityEdge display",
    },
    {
      id: 7,
      name: "Apple AirPods Pro 2",
      price: 229,
      originalPrice: 249,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.8,
      reviews: 1203,
      discount: 8,
      description: "Active noise cancellation with adaptive audio",
    },
    {
      id: 8,
      name: "Canon EOS R6 Mark II",
      price: 2499,
      originalPrice: 2699,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.9,
      reviews: 156,
      discount: 7,
      description: "Professional mirrorless camera with 24.2MP sensor",
    },
    {
      id: 9,
      name: "LG OLED C3 55-inch",
      price: 1399,
      originalPrice: 1699,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.8,
      reviews: 678,
      discount: 18,
      description: "4K OLED TV with stunning picture quality and gaming features",
    },
  ]

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="bg-card border-b sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-semibold">Electronics</h1>
              <p className="text-xs text-muted-foreground">{featuredProducts.length + products.length} products</p>
            </div>
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="px-4 py-4 space-y-6">
        {/* Category Banner */}
        <Card className="overflow-hidden bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600">
          <CardContent className="p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">Electronics Sale</h2>
            <p className="text-white/90 mb-4">Up to 30% off on premium devices</p>
            <Button variant="secondary" size="sm">
              Shop Deals
            </Button>
          </CardContent>
        </Card>

        {/* Featured Products */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Featured Products</h2>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Popular</SelectItem>
                <SelectItem value="price-low">Price: Low</SelectItem>
                <SelectItem value="price-high">Price: High</SelectItem>
                <SelectItem value="rating">Top Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            {featuredProducts.map((product) => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="flex gap-4">
                      <div className="relative w-32 h-32 flex-shrink-0">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        {product.discount > 0 && (
                          <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground">
                            -{product.discount}%
                          </Badge>
                        )}
                        {product.badge && (
                          <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                            {product.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="flex-1 p-3 flex flex-col justify-between">
                        <div>
                          <h3 className="font-semibold text-sm mb-1 line-clamp-1">{product.name}</h3>
                          <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{product.description}</p>
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium">{product.rating}</span>
                            <span className="text-xs text-muted-foreground">({product.reviews})</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-primary">${product.price}</span>
                            {product.originalPrice > product.price && (
                              <span className="text-xs text-muted-foreground line-through ml-2">
                                ${product.originalPrice}
                              </span>
                            )}
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Heart className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* All Products Grid */}
        <section>
          <h2 className="text-lg font-semibold mb-4">All Products</h2>
          <div className="grid grid-cols-2 gap-3">
            {products.map((product) => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-3">
                    <div className="relative mb-3">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={250}
                        height={250}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      {product.discount > 0 && (
                        <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground">
                          -{product.discount}%
                        </Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 h-7 w-7 bg-background/80 hover:bg-background"
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>

                    <h3 className="font-medium text-sm mb-1 line-clamp-2">{product.name}</h3>

                    <div className="flex items-center mb-2">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs text-muted-foreground ml-1">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>

                    <div>
                      <span className="font-bold text-primary">${product.price}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-xs text-muted-foreground line-through ml-1">
                          ${product.originalPrice}
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
