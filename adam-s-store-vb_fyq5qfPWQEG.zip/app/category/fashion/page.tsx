"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Star, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export default function FashionPage() {
  const [sortBy, setSortBy] = useState("popular")

  const featuredProducts = [
    {
      id: 11,
      name: "Premium Cotton T-Shirt",
      price: 29,
      originalPrice: 39,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.7,
      reviews: 234,
      discount: 26,
      badge: "Bestseller",
      description: "Comfortable everyday wear with modern fit",
    },
    {
      id: 12,
      name: "Designer Denim Jeans",
      price: 79,
      originalPrice: 99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 312,
      discount: 20,
      badge: "New",
      description: "Classic slim fit with premium denim fabric",
    },
    {
      id: 13,
      name: "Luxury Leather Jacket",
      price: 249,
      originalPrice: 329,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 156,
      discount: 24,
      badge: "Premium",
      description: "Genuine leather with modern biker style",
    },
  ]

  const products = [
    {
      id: 14,
      name: "Summer Floral Dress",
      price: 59,
      originalPrice: 79,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.6,
      reviews: 189,
      discount: 25,
      description: "Lightweight and perfect for summer",
    },
    {
      id: 15,
      name: "Casual Sneakers",
      price: 89,
      originalPrice: 109,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.7,
      reviews: 445,
      discount: 18,
      description: "Comfortable all-day wear with style",
    },
    {
      id: 16,
      name: "Wool Blend Blazer",
      price: 139,
      originalPrice: 179,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.8,
      reviews: 123,
      discount: 22,
      description: "Professional look for any occasion",
    },
    {
      id: 17,
      name: "Silk Scarf Collection",
      price: 49,
      originalPrice: 69,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.5,
      reviews: 267,
      discount: 29,
      description: "Elegant accessory in multiple colors",
    },
    {
      id: 18,
      name: "Athletic Shorts",
      price: 35,
      originalPrice: 45,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.6,
      reviews: 534,
      discount: 22,
      description: "Breathable fabric for active lifestyle",
    },
    {
      id: 19,
      name: "Designer Handbag",
      price: 199,
      originalPrice: 249,
      image: "/placeholder.svg?height=250&width=250",
      rating: 4.9,
      reviews: 89,
      discount: 20,
      description: "Luxury accessory with premium materials",
    },
  ]

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="bg-card border-b sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-semibold">Fashion</h1>
              <p className="text-xs text-muted-foreground">{featuredProducts.length + products.length} products</p>
            </div>
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="px-4 py-4 space-y-6">
        {/* Category Banner */}
        <Card className="overflow-hidden bg-gradient-to-br from-pink-500 via-rose-500 to-red-500">
          <CardContent className="p-6 text-white">
            <h2 className="text-2xl font-bold mb-2">Fashion Week</h2>
            <p className="text-white/90 mb-4">Trendy styles up to 40% off</p>
            <Button variant="secondary" size="sm">
              Explore Collection
            </Button>
          </CardContent>
        </Card>

        {/* Featured Products */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Featured Products</h2>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Popular</SelectItem>
                <SelectItem value="price-low">Price: Low</SelectItem>
                <SelectItem value="price-high">Price: High</SelectItem>
                <SelectItem value="rating">Top Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            {featuredProducts.map((product) => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="flex gap-4">
                      <div className="relative w-32 h-32 flex-shrink-0">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        {product.discount > 0 && (
                          <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground">
                            -{product.discount}%
                          </Badge>
                        )}
                        {product.badge && (
                          <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground">
                            {product.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="flex-1 p-3 flex flex-col justify-between">
                        <div>
                          <h3 className="font-semibold text-sm mb-1 line-clamp-1">{product.name}</h3>
                          <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{product.description}</p>
                          <div className="flex items-center gap-1 mb-2">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium">{product.rating}</span>
                            <span className="text-xs text-muted-foreground">({product.reviews})</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-primary">${product.price}</span>
                            {product.originalPrice > product.price && (
                              <span className="text-xs text-muted-foreground line-through ml-2">
                                ${product.originalPrice}
                              </span>
                            )}
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Heart className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* All Products Grid */}
        <section>
          <h2 className="text-lg font-semibold mb-4">All Products</h2>
          <div className="grid grid-cols-2 gap-3">
            {products.map((product) => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-3">
                    <div className="relative mb-3">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={250}
                        height={250}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      {product.discount > 0 && (
                        <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground">
                          -{product.discount}%
                        </Badge>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 h-7 w-7 bg-background/80 hover:bg-background"
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>

                    <h3 className="font-medium text-sm mb-1 line-clamp-2">{product.name}</h3>

                    <div className="flex items-center mb-2">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs text-muted-foreground ml-1">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>

                    <div>
                      <span className="font-bold text-primary">${product.price}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-xs text-muted-foreground line-through ml-1">
                          ${product.originalPrice}
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
