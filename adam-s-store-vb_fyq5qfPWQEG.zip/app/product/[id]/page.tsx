"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Star, Plus, Minus, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProductPage() {
  const [quantity, setQuantity] = useState(1)
  const [selectedImage, setSelectedImage] = useState(0)
  const [isWishlisted, setIsWishlisted] = useState(false)

  const product = {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 299,
    originalPrice: 399,
    discount: 25,
    rating: 4.5,
    reviews: 128,
    inStock: true,
    description:
      "Experience premium sound quality with these wireless headphones featuring active noise cancellation, 30-hour battery life, and premium comfort design.",
    features: [
      "Active Noise Cancellation",
      "30-hour battery life",
      "Premium comfort design",
      "Bluetooth 5.0 connectivity",
      "Quick charge technology",
    ],
    images: [
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
    ],
    colors: ["Black", "White", "Blue"],
    sizes: ["One Size"],
  }

  const relatedProducts = [
    {
      id: 2,
      name: "Bluetooth Speaker",
      price: 79,
      originalPrice: 99,
      image: "/placeholder.svg?height=150&width=150",
      rating: 4.3,
    },
    {
      id: 3,
      name: "Phone Case",
      price: 29,
      originalPrice: 39,
      image: "/placeholder.svg?height=150&width=150",
      rating: 4.6,
    },
  ]

  const handleAddToCart = () => {
    // Add to cart logic
    console.log(`Added ${quantity} items to cart`)
  }

  const handleBuyNow = () => {
    // Buy now logic
    console.log("Proceeding to checkout")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>

          <h1 className="font-semibold truncate mx-4">Product Details</h1>

          <div className="flex space-x-2">
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setIsWishlisted(!isWishlisted)}>
              <Heart className={`h-5 w-5 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
            </Button>
          </div>
        </div>
      </header>

      {/* Product Images */}
      <section className="bg-white">
        <div className="relative">
          <Image
            src={product.images[selectedImage] || "/placeholder.svg"}
            alt={product.name}
            width={400}
            height={400}
            className="w-full h-80 object-cover"
          />
          {product.discount > 0 && <Badge className="absolute top-4 left-4 bg-red-500">-{product.discount}%</Badge>}
        </div>

        {/* Image Thumbnails */}
        <div className="flex space-x-2 p-4 overflow-x-auto">
          {product.images.map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 ${
                selectedImage === index ? "border-primary" : "border-gray-200"
              }`}
            >
              <Image
                src={image || "/placeholder.svg"}
                alt={`Product ${index + 1}`}
                width={64}
                height={64}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      </section>

      {/* Product Info */}
      <section className="bg-white mt-2 p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h1 className="text-xl font-bold mb-2">{product.name}</h1>
            <div className="flex items-center mb-3">
              <div className="flex items-center">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm text-gray-600 ml-1">
                  {product.rating} ({product.reviews} reviews)
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3 mb-4">
          <span className="text-2xl font-bold text-primary">${product.price}</span>
          {product.originalPrice > product.price && (
            <span className="text-lg text-gray-500 line-through">${product.originalPrice}</span>
          )}
          {product.discount > 0 && <Badge variant="destructive">Save ${product.originalPrice - product.price}</Badge>}
        </div>

        <div className="flex items-center space-x-2 mb-4">
          <div className={`w-3 h-3 rounded-full ${product.inStock ? "bg-green-500" : "bg-red-500"}`}></div>
          <span className={`text-sm font-medium ${product.inStock ? "text-green-600" : "text-red-600"}`}>
            {product.inStock ? "In Stock" : "Out of Stock"}
          </span>
        </div>

        <Separator className="my-4" />

        {/* Quantity Selector */}
        <div className="flex items-center justify-between mb-6">
          <span className="font-medium">Quantity:</span>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="w-12 text-center font-medium">{quantity}</span>
            <Button variant="outline" size="icon" onClick={() => setQuantity(quantity + 1)}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button className="w-full" size="lg" onClick={handleBuyNow} disabled={!product.inStock}>
            Buy Now - ${product.price * quantity}
          </Button>
          <Button
            variant="outline"
            className="w-full bg-transparent"
            size="lg"
            onClick={handleAddToCart}
            disabled={!product.inStock}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Add to Cart
          </Button>
        </div>
      </section>

      {/* Product Details Tabs */}
      <section className="bg-white mt-2">
        <Tabs defaultValue="description" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="p-4">
            <p className="text-gray-700 leading-relaxed">{product.description}</p>
          </TabsContent>

          <TabsContent value="features" className="p-4">
            <ul className="space-y-2">
              {product.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                  {feature}
                </li>
              ))}
            </ul>
          </TabsContent>

          <TabsContent value="reviews" className="p-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Customer Reviews</h3>
                <Button variant="outline" size="sm">
                  Write Review
                </Button>
              </div>

              <div className="space-y-3">
                <div className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <span className="ml-2 font-medium">John D.</span>
                    </div>
                    <span className="text-sm text-gray-500">2 days ago</span>
                  </div>
                  <p className="text-gray-700">Amazing sound quality and comfortable to wear for long periods!</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </section>

      {/* Related Products */}
      <section className="bg-white mt-2 p-4">
        <h3 className="font-semibold mb-4">You might also like</h3>
        <div className="grid grid-cols-2 gap-3">
          {relatedProducts.map((item) => (
            <Link key={item.id} href={`/product/${item.id}`}>
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    width={150}
                    height={150}
                    className="w-full h-24 object-cover rounded-lg mb-2"
                  />
                  <h4 className="font-medium text-sm mb-1 line-clamp-2">{item.name}</h4>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-primary">${item.price}</span>
                    <div className="flex items-center">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs text-gray-600 ml-1">{item.rating}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Bottom Padding */}
      <div className="h-4"></div>
    </div>
  )
}
