"use client"

import React, { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { translations, type Language, type TranslationKey } from "./translations"

interface AppContextType {
  // Language
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKey) => string
  isRTL: boolean
  
  // Theme
  theme: "light" | "dark"
  toggleTheme: () => void
  
  // Cart
  cartCount: number
  setCartCount: (count: number) => void
  
  // AI Assistant
  isAIOpen: boolean
  setIsAIOpen: (open: boolean) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  // Language State
  const [language, setLanguageState] = useState<Language>("en")
  const [isRTL, setIsRTL] = useState(false)
  
  // Theme State
  const [theme, setThemeState] = useState<"light" | "dark">("light")
  
  // Cart State
  const [cartCount, setCartCount] = useState(0)
  
  // AI Assistant State
  const [isAIOpen, setIsAIOpen] = useState(false)

  // Load preferences from localStorage
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    const savedTheme = localStorage.getItem("theme") as "light" | "dark"
    const savedCartCount = localStorage.getItem("cartCount")
    
    if (savedLanguage && translations[savedLanguage]) {
      setLanguageState(savedLanguage)
      setIsRTL(savedLanguage === "ar")
      document.documentElement.dir = savedLanguage === "ar" ? "rtl" : "ltr"
      document.documentElement.lang = savedLanguage
    }
    
    if (savedTheme) {
      setThemeState(savedTheme)
      document.documentElement.classList.toggle("dark", savedTheme === "dark")
    }
    
    if (savedCartCount) {
      setCartCount(parseInt(savedCartCount, 10))
    }
  }, [])

  // Translation function
  const t = (key: TranslationKey): string => {
    return translations[language][key] || key
  }

  // Set language with persistence
  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    setIsRTL(lang === "ar")
    localStorage.setItem("language", lang)
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"
    document.documentElement.lang = lang
  }

  // Toggle theme with persistence
  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light"
    setThemeState(newTheme)
    localStorage.setItem("theme", newTheme)
    document.documentElement.classList.toggle("dark", newTheme === "dark")
  }

  // Update cart count with persistence
  const updateCartCount = (count: number) => {
    setCartCount(count)
    localStorage.setItem("cartCount", count.toString())
  }

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isRTL,
        theme,
        toggleTheme,
        cartCount,
        setCartCount: updateCartCount,
        isAIOpen,
        setIsAIOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within AppProvider")
  }
  return context
}
